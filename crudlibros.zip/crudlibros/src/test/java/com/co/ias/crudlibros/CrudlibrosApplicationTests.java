package com.co.ias.crudlibros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudlibrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
