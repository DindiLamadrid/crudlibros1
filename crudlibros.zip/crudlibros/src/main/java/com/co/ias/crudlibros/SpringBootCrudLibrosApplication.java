package com.co.ias.crudlibros;

import org.springframework.boot.SpringApplication;

public class SpringBootCrudLibrosApplication {
	public static void main(String[] args)
	{
		SpringApplication.run(SpringBootCrudLibrosApplication.class, args);
	}
}


