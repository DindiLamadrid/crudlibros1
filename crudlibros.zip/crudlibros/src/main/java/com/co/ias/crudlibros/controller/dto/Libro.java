package com.co.ias.crudlibros.controller.dto;


import jakarta.persistence.Entity;

import jakarta.persistence.Table;

public class Libro {

    Libro[] libros;
}
